# Final product-first evidence rules

## Evidence hierarchy

1. **Product/detail URL** — strongest. Use for Material and Bauteiltyp when the exact product title, breadcrumb, details, or material field supports the closed-set ID.
2. **Visible product row on category/listing page** — acceptable for Bauteiltyp and Material only when the visible row text itself contains the component/material. Do not use hidden filters as proof of a specific product.
3. **Category page** — acceptable for Bauteiltyp scope; material is review-only unless the category explicitly names a material category and the actor is a stock/material platform.
4. **Sell-guide/accepted-material page** — actor-scope evidence only, not proof of current stock.
5. **Aggregator/network/about page** — actor classification only. Direct inventory claims need product/listing evidence.
6. **Third-party directory** — review-only unless it is the only available evidence and is explicitly marked as such.

## Conservative mapping choices

- `Metall` → no closed material; map only explicit `Stahl`, `Edelstahl`, `steel`, `acier` to `mat_stahl`, and explicit aluminium to `mat_aluminium`.
- `Stein` → no closed material; map explicit `Naturstein`, `Sandstein`, `Granit`, `Muschelkalk`, `Grauwacke`, `Schiefer`, `pierre naturelle`, etc. to `mat_naturstein`.
- `Fliesen/tile/carrelage` → Bauteiltyp only unless material is explicit: `Keramik`, `Feinsteinzeug`, `porcelain`, `céramique`, `faïence`, etc.
- `Dachziegel/Ziegelsteine/brick/brique/mursten` → `mat_ziegel` when the page text directly uses those words. If only generic roof tile appears without material, keep material review-only.
- Furniture, shelves, desks, office equipment → excluded from building Bauteiltyp import unless a building-component category is explicit.
