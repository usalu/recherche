# Final actor coverage matrix — strict import candidates only

Denominator: 15 closed-set Material IDs and 15 key Bauteiltyp IDs from the brief. “Review only” means evidence exists but is not safe for import without manual page check or product-level URL.

| Actor | Status | Strict Material % | Strict Bauteiltyp % | Strict Material IDs | Strict Bauteiltyp IDs | Review-only IDs |
|---|---:|---:|---:|---|---|---|
| `articonnex` | REVIEW_ONLY_EVIDENCE_FOUND | 0.0% | 0.0% | — | — | mat_daemmstoff;mat_holz;mat_kunststoff; bt_ausbau;bt_boden;bt_daemmung;bt_fassade |
| `backacia` | REVIEW_ONLY_EVIDENCE_FOUND | 0.0% | 0.0% | — | — | mat_holz;mat_kunststoff; bt_boden;bt_tuer |
| `baticycle` | HAS_STRICT_IMPORT_CANDIDATES | 0.0% | 40.0% | — | bt_ausbau;bt_boden;bt_decke;bt_technik;bt_tuer;bt_wand | — |
| `batiterre` | HAS_STRICT_IMPORT_CANDIDATES | 33.3% | 66.7% | mat_glas;mat_gusseisen;mat_holz;mat_kunststoff;mat_ziegel | bt_ausbau;bt_boden;bt_dach;bt_daemmung;bt_fenster;bt_gelaender;bt_technik;bt_treppe;bt_tuer;bt_wand | mat_glas;mat_gusseisen;mat_holz;mat_keramik;mat_naturstein;mat_ziegel; bt_boden;bt_technik;bt_tuer;bt_wand |
| `batrecup` | NO_CLOSED_SET_MATERIAL_BT_EVIDENCE_IN_FINAL_PASS | 0.0% | 0.0% | — | — | — |
| `baukarussell` | NO_CLOSED_SET_MATERIAL_BT_EVIDENCE_IN_FINAL_PASS | 0.0% | 0.0% | — | — | — |
| `bauteilboerse_bremen` | REVIEW_ONLY_EVIDENCE_FOUND | 0.0% | 0.0% | — | — | mat_glas;mat_holz;mat_keramik;mat_kunststoff;mat_naturstein;mat_stahl; bt_ausbau;bt_boden;bt_dach;bt_fassade;bt_fenster;bt_technik;bt_treppe;bt_tuer;bt_wand |
| `bauteilladen_winterthur` | HAS_STRICT_IMPORT_CANDIDATES | 13.3% | 6.7% | mat_holz;mat_naturstein | bt_fenster | mat_holz; bt_boden;bt_fenster;bt_technik;bt_treppe;bt_tuer |
| `bauteilnetz_deutschland` | HAS_STRICT_IMPORT_CANDIDATES | 13.3% | 13.3% | mat_keramik;mat_ziegel | bt_boden;bt_dach | mat_holz;mat_keramik; bt_boden;bt_fenster;bt_technik;bt_tuer;bt_wand |
| `building_spares_market` | NO_CLOSED_SET_MATERIAL_BT_EVIDENCE_IN_FINAL_PASS | 0.0% | 0.0% | — | — | — |
| `cornermat_retrival` | HAS_STRICT_IMPORT_CANDIDATES | 26.7% | 33.3% | mat_glas;mat_holz;mat_keramik;mat_ziegel | bt_boden;bt_fenster;bt_technik;bt_tuer;bt_wand | mat_daemmstoff;mat_holz; bt_boden;bt_dach;bt_daemmung;bt_fenster;bt_technik;bt_wand |
| `cycle_up` | REVIEW_ONLY_EVIDENCE_FOUND | 0.0% | 0.0% | — | — | mat_glas;mat_kunststoff; bt_fenster |
| `cycle_zero` | REVIEW_ONLY_EVIDENCE_FOUND | 0.0% | 0.0% | — | — | mat_daemmstoff;mat_holz; bt_boden;bt_daemmung;bt_fenster;bt_technik;bt_tuer |
| `enviromate` | NO_CLOSED_SET_MATERIAL_BT_EVIDENCE_IN_FINAL_PASS | 0.0% | 0.0% | — | — | — |
| `gebruiktebouwmaterialen` | NO_CLOSED_SET_MATERIAL_BT_EVIDENCE_IN_FINAL_PASS | 0.0% | 0.0% | — | — | — |
| `genbyg` | HAS_STRICT_IMPORT_CANDIDATES | 13.3% | 26.7% | mat_glas;mat_ziegel | bt_fenster;bt_technik;bt_tuer;bt_wand | mat_holz;mat_keramik; bt_boden;bt_fenster;bt_tuer |
| `globechain` | NO_CLOSED_SET_MATERIAL_BT_EVIDENCE_IN_FINAL_PASS | 0.0% | 0.0% | — | — | — |
| `insert_marketplace` | REVIEW_ONLY_EVIDENCE_FOUND | 0.0% | 0.0% | — | — | bt_fenster;bt_tuer |
| `loopfront` | NO_CLOSED_SET_MATERIAL_BT_EVIDENCE_IN_FINAL_PASS | 0.0% | 0.0% | — | — | — |
| `material_index` | REVIEW_ONLY_EVIDENCE_FOUND | 0.0% | 0.0% | — | — | mat_ziegel; bt_tuer;bt_wand |
| `material_reuse_portal` | HAS_STRICT_IMPORT_CANDIDATES | 6.7% | 13.3% | mat_naturstein | bt_boden;bt_dach | mat_glas;mat_holz;mat_stahl; bt_boden;bt_dach;bt_decke;bt_fenster;bt_technik;bt_treppe;bt_tuer;bt_wand |
| `materialenbank_leuven_atelier_circuler` | REVIEW_ONLY_EVIDENCE_FOUND | 0.0% | 0.0% | — | — | mat_daemmstoff;mat_holz;mat_keramik;mat_kunststoff;mat_naturstein;mat_stahl; bt_boden;bt_daemmung;bt_fassade;bt_fenster;bt_technik;bt_traeger;bt_tuer;bt_wand |
| `materialrest24` | REVIEW_ONLY_EVIDENCE_FOUND | 0.0% | 0.0% | — | — | mat_holz; bt_ausbau;bt_dach;bt_technik;bt_wand |
| `new_horizon` | NO_CLOSED_SET_MATERIAL_BT_EVIDENCE_IN_FINAL_PASS | 0.0% | 0.0% | — | — | — |
| `r_place` | REVIEW_ONLY_EVIDENCE_FOUND | 0.0% | 0.0% | — | — | bt_technik |
| `raedificare` | NO_CLOSED_SET_MATERIAL_BT_EVIDENCE_IN_FINAL_PASS | 0.0% | 0.0% | — | — | — |
| `re_store_harvestmap_vienna` | NO_CLOSED_SET_MATERIAL_BT_EVIDENCE_IN_FINAL_PASS | 0.0% | 0.0% | — | — | — |
| `reempro` | HAS_STRICT_IMPORT_CANDIDATES | 13.3% | 53.3% | mat_keramik;mat_ziegel | bt_ausbau;bt_boden;bt_daemmung;bt_decke;bt_fenster;bt_technik;bt_tuer;bt_wand | — |
| `resource_marktplaats` | NO_CLOSED_SET_MATERIAL_BT_EVIDENCE_IN_FINAL_PASS | 0.0% | 0.0% | — | — | — |
| `reuse_and_trade` | REVIEW_ONLY_EVIDENCE_FOUND | 0.0% | 0.0% | — | — | mat_holz;mat_stahl; bt_gelaender;bt_technik;bt_treppe;bt_tuer |
| `rotordc` | HAS_STRICT_IMPORT_CANDIDATES | 20.0% | 6.7% | mat_glas;mat_keramik;mat_ziegel | bt_boden | mat_aluminium;mat_daemmstoff;mat_holz;mat_keramik;mat_kunststoff;mat_naturstein;mat_stahl; bt_ausbau;bt_boden;bt_dach;bt_daemmung;bt_fassade;bt_technik;bt_treppe;bt_tuer;bt_wand |
| `salvoweb` | REVIEW_ONLY_EVIDENCE_FOUND | 0.0% | 0.0% | — | — | bt_tuer |
| `salza` | NO_CLOSED_SET_MATERIAL_BT_EVIDENCE_IN_FINAL_PASS | 0.0% | 0.0% | — | — | — |
| `skop_marketplace` | REVIEW_ONLY_EVIDENCE_FOUND | 0.0% | 0.0% | — | — | mat_daemmstoff;mat_holz; bt_ausbau;bt_boden;bt_dach;bt_daemmung;bt_technik;bt_tuer;bt_wand |
| `software_restado` | HAS_STRICT_IMPORT_CANDIDATES | 26.7% | 26.7% | mat_beton;mat_holz;mat_keramik;mat_ziegel | bt_boden;bt_dach;bt_tuer;bt_wand | — |
| `surplus_building_and_plumbing_materials` | HAS_STRICT_IMPORT_CANDIDATES | 6.7% | 6.7% | mat_ziegel | bt_wand | mat_daemmstoff;mat_holz;mat_ziegel; bt_dach;bt_daemmung;bt_technik;bt_wand |
| `sustainability_yard` | REVIEW_ONLY_EVIDENCE_FOUND | 0.0% | 0.0% | — | — | mat_daemmstoff;mat_holz;mat_naturstein;mat_ziegel; bt_ausbau;bt_boden;bt_dach;bt_daemmung;bt_fassade;bt_fenster;bt_technik;bt_traeger;bt_tuer;bt_wand |
| `useagain_bauteilclick` | HAS_STRICT_IMPORT_CANDIDATES | 20.0% | 13.3% | mat_glas;mat_kunststoff;mat_stahl | bt_fenster;bt_technik | mat_glas;mat_holz;mat_keramik;mat_kunststoff; bt_tuer |
| `warp_it` | NO_CLOSED_SET_MATERIAL_BT_EVIDENCE_IN_FINAL_PASS | 0.0% | 0.0% | — | — | — |