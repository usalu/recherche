# Bauteilbörsen final audit pass 7 — Material + Bauteiltyp

This is the final consolidation pass requested on 2026-05-31. It applies the product-first evidence rule across the full 39-anchor set:

1. Use product/detail URLs when public product URLs exist.
2. Use category/list pages only for category/bauteiltyp scope or visible product rows.
3. Do not convert generic words such as `Metall`, `Stein`, `tile/carrelage/Fliesen`, or furniture/shelf listings into closed-set claims unless the page text directly supports the closed-set Material/Bauteiltyp.
4. Keep aggregator/network actors such as `material_reuse_portal` and `bauteilnetz_deutschland` in scope, but separate actor classification from direct inventory claims.
5. Keep `PruefungNachweis`, `Aufbereitungsverfahren`, and `Rueckbauverfahren` out of final import files because the brief requires graph/Cypher lookup first.

## Counts

- Actors covered: 39
- Strict import candidate rows: 107
- Review-only rows: 255
- Explicit rejected/do-not-import rows: 15

## Start here

- `csv/FINAL_STRICT_IMPORT_CANDIDATES_MATERIAL_BAUTEILTYP.csv` — only closed-set Material/Bauteiltyp rows that survived final strict filtering.
- `csv/FINAL_REVIEW_ONLY_MATERIAL_BAUTEILTYP.csv` — useful evidence that should not be imported without a manual/product-level check.
- `csv/FINAL_REJECTED_DO_NOT_IMPORT.csv` — explicit rejections from prior passes.
- `csv/FINAL_EVIDENCE_LEDGER_ALL_CLAIMS.csv` — strict + review rows together.
- `csv/FINAL_ACTOR_COVERAGE_SUMMARY.csv` and `FINAL_ACTOR_COVERAGE_MATRIX.md` — presentation/coverage view per actor.
- `json_per_actor/*.final_strict.enrichment.json` — one strict JSON per anchor.

## Important corrections in this pass

- `bauteilnetz_deutschland`: moved from network/category-only treatment to product/detail evidence where URLs exist. The user-provided Fußbodenfliese URL supports `bt_boden` and `mat_keramik`. The Dachziegel URL supports `bt_dach` and `mat_ziegel`, but the raw page field says `Material: Stein`; the Ziegel claim is based on the title/details text (`Dachziegel`, `Ziegelsteine`, `Firstziegel`) and **not** on the raw material field.
- `material_reuse_portal`: retained as aggregator/portal. Its About page proves aggregation of construction materials from multiple marketplaces, but direct Material/Bauteiltyp claims require product/listing URLs.
- Generic `Metall` is not mapped to `mat_stahl`; generic `Stein` is not mapped to `mat_naturstein`; generic `Fliesen/tile/carrelage` is not mapped to `mat_keramik` unless ceramic/Keramik/Feinsteinzeug/porcelain/faïence etc. is explicit.

## Honesty note

This package is designed for auditability, not maximal claim count. It does not certify that every marketplace product on the web has been exhaustively crawled. It records the strict claims found so far and leaves the remaining potentially useful evidence in review files.
