# PV-02 — Materialeigenschaften und Rechenstatus

## Originalquelle

- Hochgeladenes PDF: `structural_grammar_performance_validation_rules.pdf`, Seite 7 von 13.
- Dort referenzierte Quelle: Abbau/Aufbau-Handbuch, gedruckte Seiten 38–39.
- Originalquelle des Handbuchs: <https://abbauaufbau.de/wp-content/uploads/2025/10/231101_AbbauAufbau_Handbuch_AP3.pdf>

## 1. Was diese Seite eigentlich prüfen will

Die Seite behandelt Festigkeit, E-Modul, Dichte, Chlorid-/Schadstoffrisiken und Prüfmethoden.

## 2. Problem der aktuellen Regelübersetzung

Material ist kein Konnektor. Es bestimmt, ob ein Konnektor berechnet werden kann oder nur mit konservativer Annahme/Warnung existiert.

## 3. Korrigierter abstrakter Regelcheck

**Regel:** Materialeigenschaften bestimmen den Rechenstatus und die Freigabe relevanter Konnektor-Ports.

**Ebene:** Bauteil / Konnektor  
**Pakete:** Evidence Overlay + Structural + Logistics + Energy

## 4. Abstrakte Repräsentation

Material property set attached to component ID.

## 5. Minimale Eigenschaften

- concrete_strength
- tensile_strength
- e_modulus
- density
- chloride_risk
- pollutant_risk
- linked_component_id

## 6. Konnektoren

- **bearing_support:** braucht Festigkeit/Kapazität
- **node_joint:** braucht Steifigkeit/Kapazität je nach Modell
- **restraint_fixing:** braucht Festigkeit, Randabstand, Bewehrungsstatus
- **lifting_interface:** braucht Dichte/Masse
- **boundary_continuity:** braucht lambda, wenn thermisch aktiv

## 7. Ports innerhalb der Konnektoren

- **affected:** bearing_side, support_side, joint_side, fixing_side, receiving_side, lifting_side, boundary_side

## 8. Port-Kompatibilität

- keine neue Kompatibilität; Material setzt status pass/warning/blocked

## 9. Prüfschritte

- Testdaten Component-ID zugeordnet
- Dichte bekannt oder angenommen
- Festigkeit bekannt oder konservativ zugewiesen
- E-Modul vorhanden falls Steifigkeit relevant
- Chlorid/Schadstoffrisiko bewertet
- unbekannte Werte erzeugen needs_evidence

## 10. Output

- calculable
- conservative
- not_calculable
- affected_connector_status

## 11. Nicht als Konnektor modellieren

- Druckfestigkeit
- E-Modul
- Dichte
- Chloridstatus
- Schadstoffstatus

## 12. Beispielhafte Anwendung

Ein bearing_support-Port kann geometrisch kompatibel sein, bleibt aber warning, wenn die Druckfestigkeit nicht bekannt oder konservativ festgelegt ist.

---

## Kurzform für den Rule Checker

```yaml
rule_id: 07_PV_02
level: Bauteil / Konnektor
packages: Evidence Overlay + Structural + Logistics + Energy
status_output: pass | warning | blocked | not_applicable
principle: >
  Konnektor = getypte Verbindungsfunktion mit Eigenschaften.
  Port = tatsächliche anschließbare Schnittstelle innerhalb eines Konnektors.
  Kompatibilität wird Port-zu-Port geprüft.
```
