# PV-05 — Brandschutz als Assemblage-Eigenschaft

## Originalquelle

- Hochgeladenes PDF: `structural_grammar_performance_validation_rules.pdf`, Seite 10 von 13.
- Dort referenzierte Quelle: Abbau/Aufbau-Handbuch, gedruckte Seiten 117–119.
- Originalquelle des Handbuchs: <https://abbauaufbau.de/wp-content/uploads/2025/10/231101_AbbauAufbau_Handbuch_AP3.pdf>

## 1. Was diese Seite eigentlich prüfen will

Die Seite stellt klar, dass Feuerwiderstand nicht nur aus dem Material folgt. Anschlüsse, Auflager, Stahladapter, Betondeckung und Einbausituation können steuern.

## 2. Problem der aktuellen Regelübersetzung

Brandschutz sollte meist kein eigener Geometrie-Konnektor sein, sondern ein Assemblage-Check, der strukturelle und Schicht-Konnektoren liest.

## 3. Korrigierter abstrakter Regelcheck

**Regel:** Der Fire-Status einer Assemblage wird vom schwächsten relevanten Bauteil, Anschluss, Auflager oder Schutzdetail bestimmt.

**Ebene:** Assemblage / Gebäudezone  
**Pakete:** Fire Validation als Aggregator + Structural + Energy/Layer

## 4. Abstrakte Repräsentation

Fire assembly chain: component → support/connector → protection layer → compartment context.

## 5. Minimale Eigenschaften

- required_fire_class
- component_fire_status
- connector_fire_relevance
- exposed_steel_status
- concrete_cover_status
- protection_layer_status

## 6. Konnektoren

- **bearing_support:** Auflager kann Feuerstatus steuern
- **restraint_fixing:** Stahlteile/Anker können Feuerstatus steuern
- **layer_continuity:** nur wenn Brandschutzschicht konstruktiv anschließt

## 7. Ports innerhalb der Konnektoren

- **affected:** bearing_side, support_side, fixing_side, receiving_side, layer_side

## 8. Port-Kompatibilität

- layer_side ↔ layer_side falls Schutzschicht fortgeführt werden muss

## 9. Prüfschritte

- erforderliche Klasse der Zone bestimmen
- Bauteil-Feuerstatus lesen
- Auflager/Adapter prüfen
- freiliegende Stahlteile geschützt?
- Betondeckung/Querschnitt ausreichend?
- Schutzschicht kontinuierlich?
- schwächstes Glied bestimmt Output

## 10. Output

- pass
- warning: Schutzdetail/Nachweis erforderlich
- blocked: schwächstes Glied unter Anforderung

## 11. Nicht als Konnektor modellieren

- Feuerwiderstandsklasse
- ungeschütztes Stahlteil
- Fluchtweg

## 12. Beispielhafte Anwendung

Eine Decke kann selbst ausreichend sein; wenn sie auf ungeschützten Stahlkonsolen liegt, steuert die schlechtere Konsole den Fire-Status der Assemblage.

---

## Kurzform für den Rule Checker

```yaml
rule_id: 10_PV_05
level: Assemblage / Gebäudezone
packages: Fire Validation als Aggregator + Structural + Energy/Layer
status_output: pass | warning | blocked | not_applicable
principle: >
  Konnektor = getypte Verbindungsfunktion mit Eigenschaften.
  Port = tatsächliche anschließbare Schnittstelle innerhalb eines Konnektors.
  Kompatibilität wird Port-zu-Port geprüft.
```
