# PV-04 — Gesamtvalidierungsmatrix

## Originalquelle

- Hochgeladenes PDF: `structural_grammar_performance_validation_rules.pdf`, Seite 9 von 13.
- Dort referenzierte Quelle: Abbau/Aufbau-Handbuch, gedruckte Seiten 95–99.
- Originalquelle des Handbuchs: <https://abbauaufbau.de/wp-content/uploads/2025/10/231101_AbbauAufbau_Handbuch_AP3.pdf>

## 1. Was diese Seite eigentlich prüfen will

Die Seite sammelt Nachweise aus Tragfähigkeit, Gebrauchstauglichkeit, Brandschutz, Hygiene/Gesundheit/Umwelt, Barrierefreiheit, Akustik, Energie und Wärmeschutz.

## 2. Problem der aktuellen Regelübersetzung

Das ist keine einzelne Konnektorregel, sondern ein Aggregator über Package-Ergebnisse.

## 3. Korrigierter abstrakter Regelcheck

**Regel:** Eine Variante ist nur gültig, wenn alle für den Nutzungskontext relevanten Packages akzeptable Status liefern.

**Ebene:** Variante / Gebäude  
**Pakete:** Aggregator über alle Packages

## 4. Abstrakte Repräsentation

Performance matrix mit Status je Kategorie.

## 5. Minimale Eigenschaften

- use_context
- building_zone
- required_performance_classes
- unresolved_blockers
- missing_evidence

## 6. Konnektoren

- **none:** Matrix erzeugt keine Konnektoren; sie liest Status vorhandener Konnektoren

## 7. Ports innerhalb der Konnektoren

- **read_only:** alle blockierten oder gewarnten Ports aus Structural, Energy, TGA, Logistics

## 8. Port-Kompatibilität

- keine Port-Kompatibilität; Aggregation von Ergebnissen

## 9. Prüfschritte

- Nutzungskontext bestimmen
- erforderliche Kategorien aktivieren
- alle Package-Status sammeln
- blocked Ports/Konnektoren sammeln
- fehlende Nachweise listen
- relevanter blocked-Status blockiert Variante

## 10. Output

- variant_pass
- variant_warning
- variant_blocked
- missing_evidence_list
- blockers

## 11. Nicht als Konnektor modellieren

- Validierungsmatrix
- Genehmigungsstatus
- Nachweisliste

## 12. Beispielhafte Anwendung

Eine geometrisch passende Wand-Decke-Komposition kann im Structural Package pass sein, aber in der Matrix blockiert werden, wenn Fire oder Energy für diese Zone ungeklärt sind.

---

## Kurzform für den Rule Checker

```yaml
rule_id: 09_PV_04
level: Variante / Gebäude
packages: Aggregator über alle Packages
status_output: pass | warning | blocked | not_applicable
principle: >
  Konnektor = getypte Verbindungsfunktion mit Eigenschaften.
  Port = tatsächliche anschließbare Schnittstelle innerhalb eines Konnektors.
  Kompatibilität wird Port-zu-Port geprüft.
```
