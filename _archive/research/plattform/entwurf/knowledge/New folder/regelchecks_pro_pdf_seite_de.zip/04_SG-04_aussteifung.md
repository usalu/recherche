# SG-04 — Aussteifung und horizontale Stabilität

## Originalquelle

- Hochgeladenes PDF: `structural_grammar_performance_validation_rules.pdf`, Seite 4 von 13.
- Dort referenzierte Quelle: Abbau/Aufbau-Handbuch, gedruckte Seiten 165–167.
- Originalquelle des Handbuchs: <https://abbauaufbau.de/wp-content/uploads/2025/10/231101_AbbauAufbau_Handbuch_AP3.pdf>

## 1. Was diese Seite eigentlich prüfen will

Die Seite trennt implizit Schwerkrafttragwerk und horizontale Stabilität. Ein Pool aus Platten, Wänden und Stützen löst nicht automatisch Aussteifung.

## 2. Problem der aktuellen Regelübersetzung

Aussteifung darf nicht als Nebencheck der Gravity Grammar erscheinen. Sie braucht einen eigenen Gebäudegraphen.

## 3. Korrigierter abstrakter Regelcheck

**Regel:** Jede Gebäudevariante muss ein separates Aussteifungsmodell für horizontale Lasten besitzen.

**Ebene:** Gebäude  
**Pakete:** Structural Package + Logistics Package für temporäre Stabilität

## 4. Abstrakte Repräsentation

Stability graph: vertikale Aussteifungselemente, horizontale Scheiben/Kollektoren und Gründungs-/Fixierungspunkte.

## 5. Minimale Eigenschaften

- lateral_directions_covered
- bracing_type
- diaphragm_status
- foundation_connection_status
- temporary_stability_status

## 6. Konnektoren

- **node_joint:** Verbindung der Aussteifungselemente im Knoten
- **restraint_fixing:** Verankerung/Fixierung der Aussteifung
- **fixation_interface:** temporäre Montagefixierung

## 7. Ports innerhalb der Konnektoren

- **node_joint:** joint_side
- **restraint_fixing:** fixing_side, receiving_side
- **fixation_interface:** component_fixing_side, fixation_tool_side

## 8. Port-Kompatibilität

- joint_side ↔ joint_side
- fixing_side ↔ receiving_side
- component_fixing_side ↔ fixation_tool_side

## 9. Prüfschritte

- Aussteifungssystem existiert als eigener Graph
- beide Hauptrichtungen abgedeckt oder begründet
- Aussteifung führt zur Gründung
- Scheibenwirkung/Diaphragma-Pfad vorhanden
- TGA-Öffnungen schneiden keine kritischen Linien
- temporäre Stabilität während Montage möglich

## 10. Output

- pass: Stabilitätssystem vorhanden
- warning: neue Aussteifung/Kern nötig
- blocked: kein Aussteifungssystem

## 11. Nicht als Konnektor modellieren

- Aussteifungssystem selbst
- Kern als Ganzes
- temporäre Stabilität als abstrakte Eigenschaft

## 12. Beispielhafte Anwendung

Ein System aus Stützen und Decken kann vertikal funktionieren, bleibt aber blocked, wenn kein Aussteifungsgraph für horizontale Lasten vorhanden ist.

---

## Kurzform für den Rule Checker

```yaml
rule_id: 04_SG_04
level: Gebäude
packages: Structural Package + Logistics Package für temporäre Stabilität
status_output: pass | warning | blocked | not_applicable
principle: >
  Konnektor = getypte Verbindungsfunktion mit Eigenschaften.
  Port = tatsächliche anschließbare Schnittstelle innerhalb eines Konnektors.
  Kompatibilität wird Port-zu-Port geprüft.
```
