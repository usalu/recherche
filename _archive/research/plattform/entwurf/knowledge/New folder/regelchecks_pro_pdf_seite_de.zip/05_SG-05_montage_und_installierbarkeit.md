# SG-05 — Montagefähigkeit und installierbare Anschlüsse

## Originalquelle

- Hochgeladenes PDF: `structural_grammar_performance_validation_rules.pdf`, Seite 5 von 13.
- Dort referenzierte Quelle: Abbau/Aufbau-Handbuch, gedruckte Seiten 219–223.
- Originalquelle des Handbuchs: <https://abbauaufbau.de/wp-content/uploads/2025/10/231101_AbbauAufbau_Handbuch_AP3.pdf>

## 1. Was diese Seite eigentlich prüfen will

Die Seite prüft nicht nur Tragwerkslogik, sondern ob die Bauteile, Auflager, Anschlüsse, Durchdringungen und Schadensprüfungen auf der Baustelle ausführbar sind.

## 2. Problem der aktuellen Regelübersetzung

Der Check gehört in eine Montage-/Logistikregel, nicht in eine reine Strukturgrammatik.

## 3. Korrigierter abstrakter Regelcheck

**Regel:** Ein Anschluss ist nur gültig, wenn seine Ports in der geplanten Montagefolge erreichbar, ausführbar und kontrollierbar bleiben.

**Ebene:** Assemblage / Montage  
**Pakete:** Logistics Package + Structural Package + TGA Package + Evidence Overlay

## 4. Abstrakte Repräsentation

Assembly sequence graph: Bauteile, Montagefolge, Hebevorgänge, Auflagerprüfung, Fixierung, Zugangsräume, Inspektionen.

## 5. Minimale Eigenschaften

- installation_order
- component_mass
- lifting_status
- access_clearance
- connector_visibility
- condition_status_current

## 6. Konnektoren

- **bearing_support:** Auflager/Aufsetzen
- **restraint_fixing:** Fixierung/Anschlussarbeit
- **lifting_interface:** Heben und Positionieren
- **access_interface:** Zugang für Montage/Prüfung
- **penetration_connection:** TGA-Durchdringung

## 7. Ports innerhalb der Konnektoren

- **bearing_support:** bearing_side, support_side
- **restraint_fixing:** fixing_side, receiving_side
- **lifting_interface:** lifting_side, tool_side
- **access_interface:** component_access_side, site_access_side
- **penetration_connection:** penetration_side, service_side

## 8. Port-Kompatibilität

- bearing_side ↔ support_side
- fixing_side ↔ receiving_side
- lifting_side ↔ tool_side
- component_access_side ↔ site_access_side
- penetration_side ↔ service_side

## 9. Prüfschritte

- Montagefolge bekannt
- Hebepunkte vor Einbau nutzbar
- Auflagerflächen vor Absetzen sichtbar
- Fixing-Ports bis zur Ausführung erreichbar
- TGA-Durchdringungen kollidieren nicht mit Anschlusszonen
- aktuelle Schadensprüfung vorhanden

## 10. Output

- pass: montierbar
- warning: Zugangs-/Sequenzrisiko
- blocked: Anschluss nicht installierbar oder prüfbar

## 11. Nicht als Konnektor modellieren

- Montagereihenfolge
- Sichtprüfung
- Baustellenlogistik als Ganzes

## 12. Beispielhafte Anwendung

Eine Wand-Decke-Verbindung kann port-kompatibel sein, aber blocked werden, wenn der Schraubanker nach dem Auflegen der Decke nicht mehr erreichbar ist.

---

## Kurzform für den Rule Checker

```yaml
rule_id: 05_SG_05
level: Assemblage / Montage
packages: Logistics Package + Structural Package + TGA Package + Evidence Overlay
status_output: pass | warning | blocked | not_applicable
principle: >
  Konnektor = getypte Verbindungsfunktion mit Eigenschaften.
  Port = tatsächliche anschließbare Schnittstelle innerhalb eines Konnektors.
  Kompatibilität wird Port-zu-Port geprüft.
```
