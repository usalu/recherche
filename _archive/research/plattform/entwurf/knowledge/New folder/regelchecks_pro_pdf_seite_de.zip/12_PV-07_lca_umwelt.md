# PV-07 — Umwelt- und LCA-Validierung

## Originalquelle

- Hochgeladenes PDF: `structural_grammar_performance_validation_rules.pdf`, Seite 12 von 13.
- Dort referenzierte Quelle: Abbau/Aufbau-Handbuch, gedruckte Seiten 135–141.
- Originalquelle des Handbuchs: <https://abbauaufbau.de/wp-content/uploads/2025/10/231101_AbbauAufbau_Handbuch_AP3.pdf>

## 1. Was diese Seite eigentlich prüfen will

Die Seite behandelt Mengen, Lebenszyklusmodule, GWP, Vergleich mit Neubeton und den Effekt von Transporten und neuen Adaptern.

## 2. Problem der aktuellen Regelübersetzung

LCA ist kein Port-Check. Es ist eine Mengen- und Szenariobewertung; Konnektoren sind relevant, wenn sie Material, Transport oder Demontierbarkeit beeinflussen.

## 3. Korrigierter abstrakter Regelcheck

**Regel:** Jede Entwurfsvariante erhält einen Umweltscore aus wiederverwendeter Masse, vermiedenem Neumaterial, Zusatzmaterial, Transport und Rückbaubarkeit.

**Ebene:** Variante / Gebäude  
**Pakete:** LCA Aggregator + Base Geometry + Logistics + Structural

## 4. Abstrakte Repräsentation

Environmental quantity model: reused components, added connector/adaptor materials, logistics, baseline scenario.

## 5. Minimale Eigenschaften

- reused_mass
- material_type
- baseline_scenario
- transport_distance
- connector_material_quantity
- adapter_quantity
- disassembly_status

## 6. Konnektoren

- **none:** LCA erzeugt keine eigenen Konnektoren
- **reads:** restraint_fixing, bearing_support falls Material/Adapter entstehen, logistics fixation/support data

## 7. Ports innerhalb der Konnektoren

- **indirect:** Ports nur relevant, wenn der gewählte Anschluss Material oder Demontage beeinflusst

## 8. Port-Kompatibilität

- keine Port-Kompatibilität im LCA-Check

## 9. Prüfschritte

- wiederverwendete Massen sammeln
- neues Anschluss-/Adaptermaterial quantifizieren
- Transportannahmen lesen
- Baseline definieren
- prüfen ob Zusatzmaterial/Logistik Nutzen reduziert
- Demontierbarkeit aus Anschlussmethode ableiten

## 10. Output

- gwp_estimate
- avoided_impact
- added_material_burden
- logistics_burden
- disassembly_score
- variant_rank

## 11. Nicht als Konnektor modellieren

- GWP
- Transportdistanz
- wiederverwendete Masse
- Demontierbarkeit

## 12. Beispielhafte Anwendung

Viele wiederverwendete Platten können ökologisch ungünstig werden, wenn jeder Anschluss massive neue Stahladapter und lange Transporte benötigt.

---

## Kurzform für den Rule Checker

```yaml
rule_id: 12_PV_07
level: Variante / Gebäude
packages: LCA Aggregator + Base Geometry + Logistics + Structural
status_output: pass | warning | blocked | not_applicable
principle: >
  Konnektor = getypte Verbindungsfunktion mit Eigenschaften.
  Port = tatsächliche anschließbare Schnittstelle innerhalb eines Konnektors.
  Kompatibilität wird Port-zu-Port geprüft.
```
