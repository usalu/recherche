# SG-03 — Kontinuierlicher Lastpfad und vertikales Stapeln

## Originalquelle

- Hochgeladenes PDF: `structural_grammar_performance_validation_rules.pdf`, Seite 3 von 13.
- Dort referenzierte Quelle: Abbau/Aufbau-Handbuch, gedruckte Seiten 111–115.
- Originalquelle des Handbuchs: <https://abbauaufbau.de/wp-content/uploads/2025/10/231101_AbbauAufbau_Handbuch_AP3.pdf>

## 1. Was diese Seite eigentlich prüfen will

Die Seite will prüfen, ob Lasten über Bauteile, Anschlüsse, Adapter und Fundamente nachvollziehbar abgetragen werden.

## 2. Problem der aktuellen Regelübersetzung

„Wand über Wand“ oder „Stütze über Stütze“ ist nur eine Heuristik. Der Algorithmus braucht einen Lastpfadgraphen.

## 3. Korrigierter abstrakter Regelcheck

**Regel:** Jede vertikale Last muss über eine Folge kompatibler bearing_support- oder node_joint-Verbindungen bis zur Gründung verfolgt werden.

**Ebene:** Assemblage / Gebäude  
**Pakete:** Structural Package + Evidence Overlay Package

## 4. Abstrakte Repräsentation

Load-path graph: loaded surface/line → bearing_support → support → lower support → foundation.

## 5. Minimale Eigenschaften

- load_direction
- support_direction
- capacity_status
- transfer_status
- component_ids linked to placed pieces

## 6. Konnektoren

- **bearing_support:** vertikaler oder lokaler Lastübergang
- **node_joint:** Knotenübertragung bei Träger/Stütze/Rahmen

## 7. Ports innerhalb der Konnektoren

- **bearing_support:** bearing_side, support_side
- **node_joint:** joint_side

## 8. Port-Kompatibilität

- bearing_side ↔ support_side
- joint_side ↔ joint_side

## 9. Prüfschritte

- alle Decken/Träger besitzen Lastpfad
- Support wird nach unten weiterverfolgt
- Unterbrechung erzeugt transfer_required
- Transferbauteil besitzt Abstraktion und Status
- Kapazität wird nicht aus Geometrie allein angenommen
- Graph-IDs entsprechen realen Pieces

## 10. Output

- pass: kontinuierlicher Lastpfad
- warning: Transfer/Nachweis erforderlich
- blocked: Lastpfad endet ohne Support

## 11. Nicht als Konnektor modellieren

- vertikale Stapelung
- Transferbedarf
- Tragfähigkeit

## 12. Beispielhafte Anwendung

Eine Stütze auf einer Decke wird nicht automatisch verboten. Sie erzeugt transfer_required oder proof_required, solange die lokale Tragfähigkeit der Decke nicht nachgewiesen ist.

---

## Kurzform für den Rule Checker

```yaml
rule_id: 03_SG_03
level: Assemblage / Gebäude
packages: Structural Package + Evidence Overlay Package
status_output: pass | warning | blocked | not_applicable
principle: >
  Konnektor = getypte Verbindungsfunktion mit Eigenschaften.
  Port = tatsächliche anschließbare Schnittstelle innerhalb eines Konnektors.
  Kompatibilität wird Port-zu-Port geprüft.
```
