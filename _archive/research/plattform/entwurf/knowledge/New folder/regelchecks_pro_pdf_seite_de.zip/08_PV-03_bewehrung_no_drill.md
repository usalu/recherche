# PV-03 — Bewehrung, Bohrzonen und Durchdringungen

## Originalquelle

- Hochgeladenes PDF: `structural_grammar_performance_validation_rules.pdf`, Seite 8 von 13.
- Dort referenzierte Quelle: Abbau/Aufbau-Handbuch, gedruckte Seiten 40–43.
- Originalquelle des Handbuchs: <https://abbauaufbau.de/wp-content/uploads/2025/10/231101_AbbauAufbau_Handbuch_AP3.pdf>

## 1. Was diese Seite eigentlich prüfen will

Die Seite behandelt die Prüfung der Bewehrungslage und die Ableitung von erlaubten bzw. gesperrten Bohr- und Anschlusszonen.

## 2. Problem der aktuellen Regelübersetzung

Nicht jeder Konnektor muss blockiert werden. Betroffen sind invasive Konnektoren: Bohren, Ankern, Dübeln, Kernbohren, nachträgliche Bewehrungsanschlüsse.

## 3. Korrigierter abstrakter Regelcheck

**Regel:** Alle Konnektoren, deren Ports Beton durchdringen oder in ihn eingreifen, benötigen Bewehrungs- und No-drill-Validierung.

**Ebene:** Bauteil / Konnektor / Port  
**Pakete:** Evidence Overlay + Structural + TGA + Logistics bei gebohrten Hebepunkten

## 4. Abstrakte Repräsentation

Reinforcement overlay: rebar lines/zones, cover depth, no-drill zones, unknown rebar zones.

## 5. Minimale Eigenschaften

- rebar_position_status
- cover_depth_status
- no_drill_zones
- drill_permission
- edge_distance

## 6. Konnektoren

- **restraint_fixing:** Anker, Dübel, Schraube, Bewehrungsanschluss
- **penetration_connection:** Kernbohrung, Sleeve, Durchdringung
- **lifting_interface:** nur wenn gebohrter Hebeeinsatz nötig

## 7. Ports innerhalb der Konnektoren

- **restraint_fixing:** fixing_side, receiving_side
- **penetration_connection:** penetration_side, service_side
- **lifting_interface:** lifting_side

## 8. Port-Kompatibilität

- fixing_side ↔ receiving_side
- penetration_side ↔ service_side
- lifting_side ↔ tool_side, aber nur wenn Hebesystem vorhanden

## 9. Prüfschritte

- Konnektor verlangt Bohren/Einsetzen/Durchdringen?
- Portzone mit Bewehrungszonen überlagern
- No-drill-Zone getroffen?
- unbekannte Bewehrung genutzt?
- Randabstände ausreichend?
- Betondeckung kompatibel?
- TGA-Durchdringung vermeidet kritische Tragzonen?

## 10. Output

- port_status: pass | warning | blocked
- reason: rebar_conflict | unknown_rebar | insufficient_edge_distance | no_drill_zone

## 11. Nicht als Konnektor modellieren

- Bewehrung
- No-drill zone
- Betondeckung

## 12. Beispielhafte Anwendung

Ein Auflager darf als bearing_support weiter existieren. Ein zusätzlicher restraint_fixing-Port wird blockiert, wenn seine Bohrzone unbekannte oder kritische Bewehrung trifft.

---

## Kurzform für den Rule Checker

```yaml
rule_id: 08_PV_03
level: Bauteil / Konnektor / Port
packages: Evidence Overlay + Structural + TGA + Logistics bei gebohrten Hebepunkten
status_output: pass | warning | blocked | not_applicable
principle: >
  Konnektor = getypte Verbindungsfunktion mit Eigenschaften.
  Port = tatsächliche anschließbare Schnittstelle innerhalb eines Konnektors.
  Kompatibilität wird Port-zu-Port geprüft.
```
