# PV-08 — Finale Vor-Montage-Validierung

## Originalquelle

- Hochgeladenes PDF: `structural_grammar_performance_validation_rules.pdf`, Seite 13 von 13.
- Dort referenzierte Quelle: Abbau/Aufbau-Handbuch, gedruckte Seiten 219–223.
- Originalquelle des Handbuchs: <https://abbauaufbau.de/wp-content/uploads/2025/10/231101_AbbauAufbau_Handbuch_AP3.pdf>

## 1. Was diese Seite eigentlich prüfen will

Die Seite ist der letzte Status-Refresh vor dem Einbau: Lagerung, Transport und Handling können neue Schäden erzeugen.

## 2. Problem der aktuellen Regelübersetzung

Das ist keine neue Designgrammatik, sondern ein finaler Evidence-Refresh auf Bauteil- und Portebene.

## 3. Korrigierter abstrakter Regelcheck

**Regel:** Vor Installation müssen Component-ID, aktueller Zustand und alle kritischen Konnektor-Ports geprüft und aktualisiert werden.

**Ebene:** Installation / Evidence / Logistics  
**Pakete:** Evidence Overlay + Logistics + Structural

## 4. Abstrakte Repräsentation

Pre-installation inspection overlay: component ID, delivery condition, port-zone condition, installation decision.

## 5. Minimale Eigenschaften

- component_id_matches_plan
- current_damage_status
- storage_transport_damage_status
- critical_port_condition
- repair_decision
- installation_decision

## 6. Konnektoren

- **bearing_support:** kritische Auflagerports prüfen
- **restraint_fixing:** Fixingports prüfen
- **node_joint:** Jointports prüfen
- **lifting_interface:** Hebepunkte prüfen
- **support_interface:** Lager-/Stützflächen prüfen

## 7. Ports innerhalb der Konnektoren

- **bearing_support:** bearing_side, support_side
- **restraint_fixing:** fixing_side, receiving_side
- **node_joint:** joint_side
- **lifting_interface:** lifting_side
- **support_interface:** component_support_side, base_support_side

## 8. Port-Kompatibilität

- Kompatibilität bleibt gleich; Status der Ports wird aktualisiert

## 9. Prüfschritte

- Component-ID stimmt mit Montageplan überein
- aktueller Zustand vs Katalogstatus
- Transport-/Lagerschäden eintragen
- kritische Portzonen prüfen
- betroffener Port wird warning/blocked
- Entscheidung dokumentieren: einbauen, reparieren, herabstufen, ersetzen, verwerfen

## 10. Output

- install_ok
- repair_before_install
- downgrade_to_non_structural
- substitute_component
- reject
- blocked_ports
- required_actions

## 11. Nicht als Konnektor modellieren

- Lieferkontrolle
- Bauteil-ID
- Reparaturentscheidung

## 12. Beispielhafte Anwendung

Wird eine Deckenplatte beim Transport an der Auflagerkante beschädigt, wird nicht automatisch das ganze Bauteil verworfen; der betroffene bearing_side-Port kann blockiert werden.

---

## Kurzform für den Rule Checker

```yaml
rule_id: 13_PV_08
level: Installation / Evidence / Logistics
packages: Evidence Overlay + Logistics + Structural
status_output: pass | warning | blocked | not_applicable
principle: >
  Konnektor = getypte Verbindungsfunktion mit Eigenschaften.
  Port = tatsächliche anschließbare Schnittstelle innerhalb eines Konnektors.
  Kompatibilität wird Port-zu-Port geprüft.
```
