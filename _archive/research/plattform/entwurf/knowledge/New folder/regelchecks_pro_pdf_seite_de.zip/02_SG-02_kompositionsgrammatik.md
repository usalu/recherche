# SG-02 — Kompositionsgrammatik aus dem Bauteilpool

## Originalquelle

- Hochgeladenes PDF: `structural_grammar_performance_validation_rules.pdf`, Seite 2 von 13.
- Dort referenzierte Quelle: Abbau/Aufbau-Handbuch, gedruckte Seiten 60–63.
- Originalquelle des Handbuchs: <https://abbauaufbau.de/wp-content/uploads/2025/10/231101_AbbauAufbau_Handbuch_AP3.pdf>

## 1. Was diese Seite eigentlich prüfen will

Die Seite versucht, aus dem Bauteilpool eine Grammatik für wiederholbare Gebäudebausteine abzuleiten.

## 2. Problem der aktuellen Regelübersetzung

Starre Formeln wie W+S oder C+B+S sind zu eng. Die Grammatik sollte aus kompatiblen Tragrollen und Ports entstehen, nicht aus fest codierten Rezepten.

## 3. Korrigierter abstrakter Regelcheck

**Regel:** Eine Komposition ist gültig, wenn horizontale/spannende Elemente über kompatible Ports auf vertikalen oder transferierenden Elementen aufliegen können.

**Ebene:** Assemblage / Teilgebäude  
**Pakete:** Structural Package, optional Semantic Package für Rasterbezug

## 4. Abstrakte Repräsentation

Struktureller Graph mit Knoten für Supports/Joints und Flächen/Linien für Decken, Wände, Träger, Stützen.

## 5. Minimale Eigenschaften

- component_dimensions
- structural_roles
- support_spacing
- span_direction
- grid_relation optional
- adapter_need

## 6. Konnektoren

- **bearing_support:** Grundrelation zwischen tragendem und getragenem Bauteil
- **node_joint:** Knotenrelation zwischen linearen Elementen

## 7. Ports innerhalb der Konnektoren

- **bearing_support:** bearing_side, support_side
- **node_joint:** joint_side

## 8. Port-Kompatibilität

- slab.bearing_side ↔ wall.support_side
- slab.bearing_side ↔ beam.support_side
- beam.joint_side ↔ column.joint_side

## 9. Prüfschritte

- für jedes spannendes Element existiert Support
- Portrollen sind kompatibel
- Supportabstand passt zur Bauteilgröße
- bei fehlendem Direktauflager ist Transfer/Adapter explizit
- Raster wird aus Bauteilmaßen abgeleitet, nicht als Konnektor modelliert

## 10. Output

- pass: gültige Komposition
- warning: Adapter oder Transfer nötig
- blocked: Spannbauteil ohne gültigen Support

## 11. Nicht als Konnektor modellieren

- Raster
- Raummodul
- Bauteilformel

## 12. Beispielhafte Anwendung

Wand+Decke ist nicht wegen der Formel gültig, sondern weil die Wand support_side und die Decke bearing_side anbietet und beide Portrollen kompatibel sind.

---

## Kurzform für den Rule Checker

```yaml
rule_id: 02_SG_02
level: Assemblage / Teilgebäude
packages: Structural Package, optional Semantic Package für Rasterbezug
status_output: pass | warning | blocked | not_applicable
principle: >
  Konnektor = getypte Verbindungsfunktion mit Eigenschaften.
  Port = tatsächliche anschließbare Schnittstelle innerhalb eines Konnektors.
  Kompatibilität wird Port-zu-Port geprüft.
```
