# SG-01 — Struktureller Bauteilstatus

## Originalquelle

- Hochgeladenes PDF: `structural_grammar_performance_validation_rules.pdf`, Seite 1 von 13.
- Dort referenzierte Quelle: Abbau/Aufbau-Handbuch, gedruckte Seiten 31–33.
- Originalquelle des Handbuchs: <https://abbauaufbau.de/wp-content/uploads/2025/10/231101_AbbauAufbau_Handbuch_AP3.pdf>

## 1. Was diese Seite eigentlich prüfen will

Die Seite will sicherstellen, dass ein wiederverwendetes Stahlbetonbauteil nicht nur als Geometrieobjekt im Katalog liegt, sondern als tragwerksrelevantes abstraktes Modell verwendbar ist.

## 2. Problem der aktuellen Regelübersetzung

Die aktuelle Regel fasst zu viele Dinge unter „Pass“ zusammen. Für unser System ist präziser: Darf das Bauteil strukturelle Konnektoren freigeben?

## 3. Korrigierter abstrakter Regelcheck

**Regel:** Ein Bauteil darf strukturelle Konnektoren nur freigeben, wenn seine minimale strukturelle Abstraktion und sein Nachweisstatus bekannt oder konservativ gesetzt sind.

**Ebene:** Bauteil  
**Pakete:** Structural Package + Evidence Overlay Package

## 4. Abstrakte Repräsentation

Deckenplatte → 2D-Plattenfläche; Wand/Scheibe → 2D-Wandscheibe; Träger → 1D-Linie mit Querschnitt; Stütze → 1D-vertikale Linie; monolithisches Fragment → intern zerlegter Graph aus Platte/Träger/Stütze.

## 5. Minimale Eigenschaften

- component_type
- structural_abstraction
- main_orientation
- span_direction / load_direction
- material_status
- capacity_status
- evidence_status

## 6. Konnektoren

- **bearing_support:** trägt oder wird getragen
- **node_joint:** struktureller Knoten oder Endanschluss
- **restraint_fixing:** Fixierung, Anker, Dübel, Schraubanker, Bewehrungsanschluss

## 7. Ports innerhalb der Konnektoren

- **bearing_support:** bearing_side, support_side
- **node_joint:** joint_side
- **restraint_fixing:** fixing_side, receiving_side

## 8. Port-Kompatibilität

- bearing_side ↔ support_side
- joint_side ↔ joint_side
- fixing_side ↔ receiving_side

## 9. Prüfschritte

- Bauteiltyp eindeutig
- passende strukturelle Abstraktion vorhanden
- Hauptorientierung und Traglogik vorhanden oder konservativ gesetzt
- Material- und Kapazitätsstatus nicht leer
- fehlende Evidenz reduziert oder blockiert strukturelle Ports

## 10. Output

- pass: Konnektoren aktiv
- warning: Konnektoren nur mit Nachweiswarnung
- blocked: keine strukturelle Nutzung

## 11. Nicht als Konnektor modellieren

- Span direction
- No-drill zone
- Tragfähigkeit
- Bauteiltyp

## 12. Beispielhafte Anwendung

Eine Deckenplatte gibt erst dann einen bearing_support-Konnektor mit bearing_side-Port frei, wenn sie als 2D-Plattenabstraktion erkannt wurde und der strukturelle Nutzungsstatus mindestens konservativ bewertet ist.

---

## Kurzform für den Rule Checker

```yaml
rule_id: 01_SG_01
level: Bauteil
packages: Structural Package + Evidence Overlay Package
status_output: pass | warning | blocked | not_applicable
principle: >
  Konnektor = getypte Verbindungsfunktion mit Eigenschaften.
  Port = tatsächliche anschließbare Schnittstelle innerhalb eines Konnektors.
  Kompatibilität wird Port-zu-Port geprüft.
```
