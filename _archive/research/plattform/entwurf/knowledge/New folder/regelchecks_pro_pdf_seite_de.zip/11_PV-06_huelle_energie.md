# PV-06 — Gebäudehülle und thermische Validierung

## Originalquelle

- Hochgeladenes PDF: `structural_grammar_performance_validation_rules.pdf`, Seite 11 von 13.
- Dort referenzierte Quelle: Abbau/Aufbau-Handbuch, gedruckte Seiten 123–125.
- Originalquelle des Handbuchs: <https://abbauaufbau.de/wp-content/uploads/2025/10/231101_AbbauAufbau_Handbuch_AP3.pdf>

## 1. Was diese Seite eigentlich prüfen will

Die Seite wird relevant, wenn ein wiederverwendetes Stahlbetonelement Fassade, Dach, Erd-/Bodenkontakt oder Außenklima berührt.

## 2. Problem der aktuellen Regelübersetzung

Nicht jedes Bauteil braucht Hüllenprüfung. Der Check wird nur aktiv, wenn das Bauteil eine Hüllenrolle bekommt.

## 3. Korrigierter abstrakter Regelcheck

**Regel:** Ein Bauteil mit Hüllenrolle muss an ein vollständiges Grenzflächen-, Schicht- und Dichtungsmodell angeschlossen sein.

**Ebene:** Bauteil / Assemblage  
**Pakete:** Energy / Envelope + TGA bei Durchdringungen + Structural bei Wärmebrücken an Anschlüssen

## 4. Abstrakte Repräsentation

Thermal boundary model: boundary surfaces, layer interfaces, penetration zones, bridge risk zones, moisture risk zones.

## 5. Minimale Eigenschaften

- thermal_role
- u_value_target
- layer_build_up
- lambda_values
- moisture_strategy

## 6. Konnektoren

- **boundary_continuity:** thermische/luftdichte Grenzfläche geht weiter
- **layer_continuity:** Dämm-/Feuchte-/Schutzschicht geht weiter
- **penetration_seal:** Durchdringung wird abgedichtet

## 7. Ports innerhalb der Konnektoren

- **boundary_continuity:** boundary_side
- **layer_continuity:** layer_side
- **penetration_seal:** penetration_side, seal_side

## 8. Port-Kompatibilität

- boundary_side ↔ boundary_side
- layer_side ↔ layer_side
- penetration_side ↔ seal_side

## 9. Prüfschritte

- Hüllenrolle bestimmen
- bei interior not_applicable oder reduzierter Check
- Grenzfläche lokalisieren
- Schichtaufbau definiert?
- U-Wert für Gesamtaufbau berechnen
- Durchdringungen versiegelt?
- Wärmebrücken als Risiko-/Zonenstatus führen

## 10. Output

- not_applicable
- pass
- warning: build-up missing
- blocked: envelope role without valid layer/seal model

## 11. Nicht als Konnektor modellieren

- U-Wert
- Wärmebrücke
- Dämmstoffdicke

## 12. Beispielhafte Anwendung

Eine Deckenplatte innen braucht keinen aktiven Energy-Konnektor. Als Dach braucht sie boundary_continuity, layer_continuity und ggf. penetration_seal.

---

## Kurzform für den Rule Checker

```yaml
rule_id: 11_PV_06
level: Bauteil / Assemblage
packages: Energy / Envelope + TGA bei Durchdringungen + Structural bei Wärmebrücken an Anschlüssen
status_output: pass | warning | blocked | not_applicable
principle: >
  Konnektor = getypte Verbindungsfunktion mit Eigenschaften.
  Port = tatsächliche anschließbare Schnittstelle innerhalb eines Konnektors.
  Kompatibilität wird Port-zu-Port geprüft.
```
