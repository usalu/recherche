# PV-01 — Zustandstriage und Nutzungsstatus

## Originalquelle

- Hochgeladenes PDF: `structural_grammar_performance_validation_rules.pdf`, Seite 6 von 13.
- Dort referenzierte Quelle: Abbau/Aufbau-Handbuch, gedruckte Seiten 35–37.
- Originalquelle des Handbuchs: <https://abbauaufbau.de/wp-content/uploads/2025/10/231101_AbbauAufbau_Handbuch_AP3.pdf>

## 1. Was diese Seite eigentlich prüfen will

Die Seite bewertet Zustand, sichtbare Schäden, Risse, Abplatzungen, Korrosion, Reparaturen und Restnutzungsrisiko.

## 2. Problem der aktuellen Regelübersetzung

Zustand ist kein eigener Konnektor. Er ist ein Evidence Overlay, das vorhandene Ports freigibt, warnt oder blockiert.

## 3. Korrigierter abstrakter Regelcheck

**Regel:** Zustandsinformationen verändern die Nutzbarkeit von Konnektor-Ports.

**Ebene:** Bauteil / Evidence  
**Pakete:** Evidence Overlay + Structural + Logistics + Semantic

## 4. Abstrakte Repräsentation

Condition overlay: damage zones, crack lines, spalling zones, corrosion risk zones, repair zones.

## 5. Minimale Eigenschaften

- damage_type
- location
- severity
- affected_package
- confidence

## 6. Konnektoren

- **none:** Evidence erzeugt keine Design-Konnektoren

## 7. Ports innerhalb der Konnektoren

- **affected:** bearing_side, support_side, fixing_side, receiving_side, lifting_side, component_support_side, visible_side

## 8. Port-Kompatibilität

- keine neue Kompatibilität; Evidence modifiziert bestehende Ports

## 9. Prüfschritte

- Schaden geometrisch lokalisieren
- Schaden mit Portzonen überlagern
- tragende Portzone getroffen?
- Hebezone getroffen?
- sichtbare Wiederverwendungsfläche betroffen?
- Schweregrad bekannt?

## 10. Output

- structural_use
- limited_structural_use
- repair_before_use
- non_structural_only
- rejected
- port_effect: warning | blocked | confidence_reduced

## 11. Nicht als Konnektor modellieren

- Riss
- Abplatzung
- Korrosion
- Reparaturzone
- Restnutzungsdauer

## 12. Beispielhafte Anwendung

Eine Kantenabplatzung blockiert nicht automatisch das ganze Bauteil. Sie blockiert oder warnt nur den bearing_side-Port, wenn sie dessen Auflagerzone überlappt.

---

## Kurzform für den Rule Checker

```yaml
rule_id: 06_PV_01
level: Bauteil / Evidence
packages: Evidence Overlay + Structural + Logistics + Semantic
status_output: pass | warning | blocked | not_applicable
principle: >
  Konnektor = getypte Verbindungsfunktion mit Eigenschaften.
  Port = tatsächliche anschließbare Schnittstelle innerhalb eines Konnektors.
  Kompatibilität wird Port-zu-Port geprüft.
```
